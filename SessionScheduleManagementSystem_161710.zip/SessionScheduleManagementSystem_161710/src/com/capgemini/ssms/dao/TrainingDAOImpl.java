/**
 * 
 */
package com.capgemini.ssms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.ssms.exception.ScheduledSessionException;
import com.capgemini.ssms.model.ScheduledSessions;

/**
 * @author swtalukd
 *
 */
@Repository
public class TrainingDAOImpl implements ITrainingDAO 
{
	@PersistenceContext
	EntityManager entityManager;
	
	
	/* (non-Javadoc)
	 * @see com.capgemini.ssms.dao.ITrainingDAO#viewScheduledSession()
	 */
	@Override
	public ArrayList<ScheduledSessions> viewScheduledSession() throws ScheduledSessionException
	{
		
			ArrayList<ScheduledSessions> list = new ArrayList<ScheduledSessions>();
			String jpql = "Select session from ScheduledSessions session";
			TypedQuery<ScheduledSessions> query = entityManager.createQuery(jpql, ScheduledSessions.class);
			list = (ArrayList<ScheduledSessions>) query.getResultList();
			if(list!=null)
			{
			return list;
			}
			else
			{
				throw new ScheduledSessionException("no Scheduled Session");
			}
		
		
	}

	
	/* (non-Javadoc)
	 * @see com.capgemini.ssms.dao.ITrainingDAO#findSessionName()
	 */
	@Override
	public String findSessionName() throws ScheduledSessionException
	{
		String jpql ="Select ss.name from ScheduledSessions ss where ss.id = 1";
		TypedQuery<String> query = entityManager.createQuery(jpql,String.class);
		//Query query=entityManager.createNamedQuery("q2");
		String sessionName = query.getSingleResult();
		
		if(sessionName!=null)
		{
			return sessionName;
		}
		else
		{
			throw new ScheduledSessionException("no Scheduled Session");
		}
	}

}
