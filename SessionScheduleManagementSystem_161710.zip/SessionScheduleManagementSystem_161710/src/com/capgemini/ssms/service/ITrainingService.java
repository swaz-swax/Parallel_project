/**
 * 
 */
package com.capgemini.ssms.service;

import java.util.ArrayList;

import com.capgemini.ssms.exception.ScheduledSessionException;
import com.capgemini.ssms.model.ScheduledSessions;


/**
 * @author Swarup Talukdar
 *
 */
public interface ITrainingService 
{
	public ArrayList<ScheduledSessions> viewScheduledSession() throws ScheduledSessionException;

	public String findSessionName() throws ScheduledSessionException;
}
